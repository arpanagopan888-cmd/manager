export interface Product {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  category: 'men' | 'women' | 'accessories';
  isTrending?: boolean;
  isNewArrival?: boolean;
  isBestSeller?: boolean;
  tag?: string; // 'Hot', 'Selling Fast', 'Top Rated', etc.
  rating?: number;
  image: string;
  description: string;
  sizes: string[];
  colors: { name: string; hex: string }[];
  details: string[];
}

export interface CartItem {
  product: Product;
  quantity: number;
  selectedSize: string;
  selectedColor: { name: string; hex: string };
}

export interface UserProfile {
  email: string;
  name: string;
  isSubscribedToPrime: boolean;
  favorites: string[]; // List of product IDs
  orders: {
    id: string;
    date: string;
    items: { productName: string; quantity: number; price: number }[];
    total: number;
    status: string;
  }[];
}
