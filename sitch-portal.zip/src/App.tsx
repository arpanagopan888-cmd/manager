import { useState, useMemo, FormEvent } from 'react';
import {
  Menu,
  Search,
  User,
  ShoppingBag,
  Heart,
  Star,
  ChevronRight,
  TrendingUp,
  Award,
  Clock,
  ArrowRight,
  Mail,
  CheckCircle2,
  Filter,
  Plus,
  Compass,
  Sparkles,
  ShieldAlert,
  ArrowLeft,
  X,
  CreditCard,
  Crown
} from 'lucide-react';

import { products, curatedCollections } from './data';
import { Product, CartItem, UserProfile } from './types';
import ShaderCanvas from './components/ShaderCanvas';
import NavigationDrawer from './components/NavigationDrawer';
import ProductDetailModal from './components/ProductDetailModal';
import BagDrawer from './components/BagDrawer';

export default function App() {
  // Navigation & Drawer States
  const [currentView, setCurrentView] = useState<'home' | 'men' | 'women' | 'accessories' | 'collections' | 'profile' | 'about'>('home');
  const [isNavDrawerOpen, setIsNavDrawerOpen] = useState(false);
  const [isBagOpen, setIsBagOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  // Search State
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchActive, setIsSearchActive] = useState(false);

  // Cart / Bag State
  const [cart, setCart] = useState<CartItem[]>([]);

  // User Profile State (Simulated Persistent UI)
  const [isLoggedIn, setIsLoggedIn] = useState(true);
  const [userEmail, setUserEmail] = useState('arpanagopan888@gmail.com');
  const [isPrime, setIsPrime] = useState(false);
  const [favorites, setFavorites] = useState<string[]>(['amber-silk-gown']); // Starts with one favorited
  const [orders, setOrders] = useState<UserProfile['orders']>([
    {
      id: 'SITCH-559124',
      date: '2026-05-18',
      items: [{ productName: 'Essential Tech Blazer', quantity: 1, price: 249.00 }],
      total: 249.00,
      status: 'Delivered'
    }
  ]);

  // Auth Modal State
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [inputEmail, setInputEmail] = useState('');
  const [inputName, setInputName] = useState('');

  // Newsletter State
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [newsletterSubscribed, setNewsletterSubscribed] = useState(false);

  // App Alerts / Toast Notifications
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3000);
  };

  // Event Handlers
  const handleToggleFavorite = (productId: string) => {
    if (favorites.includes(productId)) {
      setFavorites(favorites.filter(id => id !== productId));
      triggerToast('Removed item from your Favorites');
    } else {
      setFavorites([...favorites, productId]);
      triggerToast('Saved item to your Favorites');
    }
  };

  const handleAddToBag = (product: Product, size: string, color: { name: string; hex: string }, qty: number) => {
    // Check if item already exists with matching size and color choice
    const duplicateIdx = cart.findIndex(
      item =>
        item.product.id === product.id &&
        item.selectedSize === size &&
        item.selectedColor.name === color.name
    );

    if (duplicateIdx > -1) {
      const updated = [...cart];
      updated[duplicateIdx].quantity += qty;
      setCart(updated);
    } else {
      setCart([...cart, { product, selectedSize: size, selectedColor: color, quantity: qty }]);
    }
    triggerToast(`Added ${qty}x ${product.name} to your bag`);
  };

  const handleUpdateCartQty = (idx: number, newQty: number) => {
    const updated = [...cart];
    updated[idx].quantity = newQty;
    setCart(updated);
  };

  const handleRemoveCartItem = (idx: number) => {
    const name = cart[idx].product.name;
    setCart(cart.filter((_, i) => i !== idx));
    triggerToast(`Removed ${name} from your bag`);
  };

  const handleCheckoutComplete = () => {
    // Save order
    const newOrder = {
      id: 'SITCH-' + Math.floor(100000 + Math.random() * 900000),
      date: new Date().toISOString().split('T')[0],
      items: cart.map(item => ({
        productName: item.product.name,
        quantity: item.quantity,
        price: item.product.price
      })),
      total: cart.reduce((acc, item) => acc + item.product.price * item.quantity, 0),
      status: 'Processing Logistics'
    };

    setOrders([newOrder, ...orders]);
    setCart([]); // Clear cart
    triggerToast('Receipt order locked! Express couriers deployed.');
  };

  const handleAuthSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!inputEmail) return;
    setUserEmail(inputEmail);
    setIsLoggedIn(true);
    setShowAuthModal(false);
    triggerToast(`Authenticated as ${inputEmail}`);
  };

  const handleSignOut = () => {
    setIsLoggedIn(false);
    setUserEmail('');
    setIsPrime(false);
    triggerToast('Logged out of Sitch system session');
  };

  const handleNewsletterSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail) return;
    setNewsletterSubscribed(true);
    triggerToast('Exclusive catalogue list joined successfully!');
  };

  const handleJoinPrime = () => {
    setIsPrime(true);
    triggerToast('Welcome to SITCH PRIME! Enjoy complimentary DHL express.');
  };

  // Filtered Products for Galleries
  const filteredProducts = useMemo(() => {
    return products.filter(product => {
      // Direct category filter
      if (currentView === 'men' && product.category !== 'men') return false;
      if (currentView === 'women' && product.category !== 'women') return false;
      if (currentView === 'accessories' && product.category !== 'accessories') return false;

      // Search filtration
      if (isSearchActive && searchQuery) {
        const query = searchQuery.toLowerCase();
        return (
          product.name.toLowerCase().includes(query) ||
          product.description.toLowerCase().includes(query) ||
          product.category.toLowerCase().includes(query)
        );
      }

      return true;
    });
  }, [currentView, searchQuery, isSearchActive]);

  // Dynamic values
  const cartItemCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  return (
    <div className="bg-[#f9f9f9] text-[#1a1c1c] min-h-screen flex flex-col font-sans select-none overflow-x-hidden antialiased">
      
      {/* Toast Notification HUD */}
      {toastMessage && (
        <div className="fixed bottom-6 left-1/2 transform -translate-x-1/2 z-50 bg-[#1a1c1c] text-white py-3.5 px-6 rounded-2xl shadow-2xl flex items-center gap-3.5 border border-[#ff6b00]/20 text-xs font-bold tracking-wider animate-bounce">
          <span className="w-2 h-2 rounded-full bg-[#ff6b00] animate-ping" />
          <span>{toastMessage.toUpperCase()}</span>
        </div>
      )}

      {/* FIXED NAVIGATION APP BAR */}
      <header className="fixed top-0 w-full z-45 bg-[#f9f9f9]/85 backdrop-blur-xl border-b border-[#1a1c1c]/10">
        <div className="flex justify-between items-center w-full px-5 md:px-16 py-4.5 max-w-7xl mx-auto">
          
          {/* Menu Drawer toggle */}
          <button
            onClick={() => setIsNavDrawerOpen(true)}
            className="text-[#a04100] active:scale-90 hover:opacity-80 transition-all p-2 rounded-full hover:bg-[#ff6b00]/10"
            title="Menu"
          >
            <Menu className="w-6 h-6" />
          </button>

          {/* Logo Heading click to Home */}
          <button
            onClick={() => {
              setCurrentView('home');
              setIsSearchActive(false);
              setSearchQuery('');
            }}
            className="font-playfair text-xl md:text-2xl font-bold uppercase tracking-tighter text-[#1a1c1c] transition-all hover:opacity-70 active:scale-98"
          >
            SITCH PORTAL
          </button>

          {/* Actions panel */}
          <div className="flex items-center gap-2 md:gap-4.5">
            {/* Search toggler */}
            <button
              onClick={() => {
                setIsSearchActive(!isSearchActive);
                if (isSearchActive) setSearchQuery('');
              }}
              className={`p-2 rounded-full transition-colors ${
                isSearchActive ? 'bg-[#ff6b00]/10 text-[#a04100]' : 'text-[#1a1c1c] hover:bg-zinc-100'
              }`}
              title="Search Portal"
            >
              <Search className="w-5 h-5" />
            </button>

            {/* Profile page index toggler */}
            <button
              onClick={() => setCurrentView('profile')}
              className={`p-2 rounded-full transition-colors ${
                currentView === 'profile' ? 'bg-[#ff6b00]/10 text-[#a04100]' : 'text-[#a04100] hover:bg-zinc-100'
              }`}
              title="Sitch Auth Panel"
            >
              <User className="w-5 h-5" />
            </button>

            {/* Favorite Counter badge */}
            <button
              onClick={() => setCurrentView('profile')}
              className="relative p-2 rounded-full text-[#5f5e5e] hover:bg-zinc-100 transition-colors hidden sm:block"
              title="Favorites Wishlist"
            >
              <Heart className="w-5 h-5" />
              {favorites.length > 0 && (
                <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-[#ff6b00] rounded-full text-[9px] font-bold text-white flex items-center justify-center">
                  {favorites.length}
                </span>
              )}
            </button>

            {/* Cart toggle bag button */}
            <button
              onClick={() => setIsBagOpen(true)}
              className="relative p-2 md:pl-2.5 rounded-xl bg-[#1a1c1c] text-white flex gap-1.5 items-center hover:bg-[#ff6b00] transition-colors active:scale-95 shadow-sm"
              title="Shopping Bag"
            >
              <ShoppingBag className="w-4.5 h-4.5" />
              <span className="text-xs font-bold px-1 hidden md:inline">Bag</span>
              <span className="w-4.5 h-4.5 bg-white text-[#1a1c1c] rounded-full text-[10px] font-bold flex items-center justify-center">
                {cartItemCount}
              </span>
            </button>
          </div>

        </div>

        {/* Dynamic Expandable Search Input Row */}
        {isSearchActive && (
          <div className="bg-white border-t border-[#1a1c1c]/10 py-3.5 px-5 md:px-16 animate-fade-in">
            <div className="max-w-3xl mx-auto relative flex items-center">
              <input
                type="text"
                autoFocus
                placeholder="Search high-street luxury index... (e.g., coat, silk, blazer, sneakers)"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full h-11 pl-11 pr-10 border border-[#1a1c1c]/10 rounded-xl text-sm focus:border-[#ff6b00] focus:ring-1 focus:ring-[#ff6b00] outline-none font-medium"
              />
              <Search className="w-4.5 h-4.5 absolute left-4 text-[#5f5e5e]" />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="w-7 h-7 rounded-full bg-stone-100 hover:bg-stone-200 flex items-center justify-center absolute right-3 text-[#1a1c1c]/60"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
            {/* Quick Suggestions tags table */}
            <div className="max-w-3xl mx-auto flex flex-wrap gap-2 mt-2.5 justify-center items-center text-xs text-[#5f5e5e]">
              <span className="font-semibold uppercase tracking-wider text-[10px]">Trending Indexes:</span>
              {['Amber', 'Wool', 'Silk', 'Blazer', 'Sneakers', 'Evening'].map((kw) => (
                <button
                  key={kw}
                  onClick={() => setSearchQuery(kw)}
                  className="px-2.5 py-1 rounded bg-stone-100 hover:bg-[#ff6b00]/15 hover:text-[#a04100] transition-colors"
                >
                  {kw}
                </button>
              ))}
            </div>
          </div>
        )}
      </header>

      {/* MAIN LAYOUT CANVAS PT-16 */}
      <main className="pt-16 flex-grow">

        {/* 1. SEPARATE PAGE VIEW: PROFILE INDEX / ACCOUNT & WISHLIST */}
        {currentView === 'profile' && (
          <div className="max-w-4xl mx-auto px-5 py-10 animate-fade-in space-y-10">
            {/* Nav Back Header */}
            <button
              onClick={() => setCurrentView('home')}
              className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-[#a04100] hover:underline"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back to luxury portal</span>
            </button>

            {/* Profile Info block */}
            <div className="p-8 rounded-3xl bg-white border border-[#1a1c1c]/10 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
              <div>
                <span className="text-[10px] bg-[#a04100] text-white py-1 px-3.5 rounded-full uppercase tracking-widest font-bold">
                  Sitch Registry
                </span>
                <h2 className="font-playfair text-3xl font-bold text-[#1a1c1c] mt-3">
                  Account Overview
                </h2>
                <p className="text-sm text-[#5f5e5e] mt-2.5">
                  Secure Customer Session Email: <strong>{isLoggedIn ? userEmail : 'Unauthenticated'}</strong>
                </p>
                {isPrime && (
                  <div className="inline-flex items-center gap-2 mt-4 bg-amber-500/10 border border-amber-500/30 text-[#a04100] px-4 py-1.5 rounded-xl text-xs font-bold">
                    <Crown className="w-4 h-4 fill-amber-500" />
                    <span>SITCH PRIME MEMBER ACTIVE</span>
                  </div>
                )}
              </div>

              {isLoggedIn ? (
                <div className="flex gap-3">
                  {!isPrime && (
                    <button
                      onClick={handleJoinPrime}
                      className="bg-gradient-to-r from-amber-500 to-[#ff6b00] text-white px-5 py-3 rounded-xl text-xs font-bold uppercase tracking-wider hover:brightness-110 transition-all active:scale-95 shadow-md flex items-center gap-2"
                    >
                      <Crown className="w-4 h-4" />
                      JOIN SITCH PRIME
                    </button>
                  )}
                  <button
                    onClick={handleSignOut}
                    className="border border-[#ba1a1a] text-[#ba1a1a] hover:bg-red-50/50 px-5 py-3 rounded-xl text-xs font-bold uppercase tracking-wider transition-all"
                  >
                    Disconnect
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => setShowAuthModal(true)}
                  className="bg-[#ff6b00] text-white px-6 h-12 rounded-xl text-xs font-bold uppercase tracking-widest hover:bg-[#a04100] transition-colors shadow-md"
                >
                  SIGN IN NOW
                </button>
              )}
            </div>

            {/* Favorites Wishlist gallery */}
            <div className="bg-white p-8 rounded-3xl border border-[#1a1c1c]/10">
              <h3 className="font-playfair text-xl font-bold text-[#1a1c1c] mb-6 flex items-center gap-2">
                <Heart className="w-5.5 h-5.5 text-[#ff6b00] fill-[#ff6b00]" />
                <span>Your Curated Wishlist ({favorites.length})</span>
              </h3>

              {favorites.length === 0 ? (
                <p className="text-xs text-[#5f5e5e]">
                  Your design wishlist is empty. Tap the Heart icons on luxury products to pin them here for instant review.
                </p>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                  {products
                    .filter((p) => favorites.includes(p.id))
                    .map((product) => (
                      <div key={product.id} className="relative border border-[#1a1c1c]/5 p-3 rounded-2xl bg-[#f9f9f9] group">
                        <button
                          onClick={() => handleToggleFavorite(product.id)}
                          className="absolute top-5 right-5 z-10 w-9 h-9 rounded-full bg-white flex items-center justify-center text-[#ff6b00]"
                        >
                          <X className="w-4 h-4" />
                        </button>
                        <div className="aspect-[3/4] rounded-xl overflow-hidden mb-3 bg-[#eeeeee]">
                          <img src={product.image} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" alt="" />
                        </div>
                        <h4 className="font-semibold text-xs text-[#1a1c1c] uppercase tracking-wider truncate">{product.name}</h4>
                        <p className="text-xs font-bold text-[#a04105] mt-1">${product.price.toFixed(2)}</p>
                        <button
                          onClick={() => setSelectedProduct(product)}
                          className="w-full mt-4 py-2 bg-white hover:bg-[#1a1c1c] hover:text-white border border-[#1a1c1c]/10 text-xs font-bold uppercase tracking-widest rounded-lg transition-transform"
                        >
                          Quick View
                        </button>
                      </div>
                    ))}
                </div>
              )}
            </div>

            {/* Orders log history */}
            <div className="bg-white p-8 rounded-3xl border border-[#1a1c1c]/10">
              <h3 className="font-playfair text-xl font-bold text-[#1a1c1c] mb-6 flex items-center gap-2">
                <Clock className="w-5.5 h-5.5 text-[#ff6b00]" />
                <span>Logistics & Order Log ({orders.length})</span>
              </h3>

              {orders.length === 0 ? (
                <p className="text-xs text-[#5f5e5e]">No logs detected. Checkout items in your Bag to stream logistic trails.</p>
              ) : (
                <div className="space-y-4">
                  {orders.map((order) => (
                    <div key={order.id} className="border border-[#1a1c1c]/10 p-5 rounded-2xl space-y-3 bg-[#f9f9f9]">
                      <div className="flex flex-wrap justify-between items-center text-xs font-semibold uppercase tracking-wider">
                        <span className="text-gray-500">Receipt ID: <strong className="text-[#1a1c1c]">{order.id}</strong></span>
                        <span className="text-gray-500">Date: <strong className="text-[#1a1c1c]">{order.date}</strong></span>
                        <span className="bg-amber-100 text-[#a04100] px-3 py-1 rounded-full text-[10px] font-bold">
                          {order.status}
                        </span>
                      </div>
                      <div className="border-t border-[#1a1c1c]/5 pt-3">
                        <ul className="text-xs text-[#5f5e5e] list-disc list-inside space-y-1">
                          {order.items.map((item, idx) => (
                            <li key={idx}>
                              {item.productName} (x{item.quantity}) - <span className="font-bold text-[#1a1c1c]">${item.price.toFixed(2)}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                      <div className="border-t border-[#1a1c1c]/5 pt-3 flex justify-between items-center text-xs font-bold">
                        <span className="text-[#5f5e5e] uppercase">Grand Spent:</span>
                        <span className="text-lg text-[#a04100] font-bold">${order.total.toFixed(2)}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

          </div>
        )}

        {/* 2. SEPARATE PAGE VIEW: ABOUT PHILOSOPHY */}
        {currentView === 'about' && (
          <div className="max-w-3xl mx-auto px-5 py-12 animate-fade-in space-y-8 text-center">
            <button
              onClick={() => setCurrentView('home')}
              className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-widest text-[#a04100] hover:underline"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back to home catalog</span>
            </button>

            <span className="text-[10px] text-[#ff6b00] font-bold uppercase tracking-[0.3em] block">
              ESTABLISHED 2026 CO.
            </span>
            <h2 className="font-playfair text-4xl font-bold text-[#1a1c1c] leading-tight">
              A Sincere Ode to High-Street Digital Luxury
            </h2>
            <p className="text-sm text-[#5f5e5e] leading-relaxed text-left max-w-2xl mx-auto space-y-4">
              <span>
                At Sitch Portal, we reject cookie-cutter retail engines. We view apparel as an extension of structural discipline—an architecture crafted for the high-end digital nomad. 
              </span>
              <br /><br />
              <span>
                By sourcing GOTS-certified organic double-faced wool, French sew seam formulations, and 30mm Italian mulberry silks, we deliver products made to endure both light and form. Each piece is constructed programmatically, and shipped carbon-neutrally in re-usable custom bags.
              </span>
            </p>

            <div className="grid grid-cols-3 gap-4 border-t border-b border-[#1a1c1c]/10 py-6 my-10 font-bold uppercase tracking-wider text-[10px] text-[#a04100]">
              <div>
                <span className="block text-2xl font-light text-[#1a1c1c] mb-1">100%</span>
                ORGANIC WOOL
              </div>
              <div>
                <span className="block text-2xl font-light text-[#1a1c1c] mb-1">ITALIAN</span>
                GRAIN LEATHER
              </div>
              <div>
                <span className="block text-2xl font-light text-[#1a1c1c] mb-1">SECURE</span>
                CARBON SHIPPED
              </div>
            </div>

            <button
              onClick={() => setCurrentView('home')}
              className="h-12 px-8 bg-[#1a1c1c] text-white text-xs font-bold tracking-widest uppercase rounded-lg hover:bg-[#ff6b00] transition-colors"
            >
              Browse our catalog
            </button>
          </div>
        )}

        {/* 3. PRIMARY VIEW: PORTAL GALLERY (HOME OR CATEGORIES INDICES) */}
        {(currentView === 'home' || currentView === 'men' || currentView === 'women' || currentView === 'accessories' || currentView === 'collections') && (
          <div className="space-y-16">
            
            {/* HERO HERO HERO COVER SECTION */}
            {currentView === 'home' && !isSearchActive && (
              <section className="relative h-[85vh] overflow-hidden flex flex-col justify-end p-6 md:p-16">
                
                {/* Embedded WebGL animated liquid shader backdrop */}
                <div className="absolute inset-0 w-full h-full z-0 opacity-45">
                  <ShaderCanvas />
                </div>

                {/* Cover High-End Photograph Layer */}
                <div className="absolute inset-0 z-0">
                  <img
                    alt="Luxury High-Street Fashion Editorial Sitch Portal"
                    className="w-full h-full object-cover object-center scale-100 transition-transform duration-1000"
                    src="https://lh3.googleusercontent.com/aida-public/AB6AXuAso2U-TAeS2C2nYVGDBtiVeH3iKLYP5ZI8Dhmd7_8JiWCkFopJb7gSxM79frx9V5Ni17eMi18cZyLESxvokfL1SKSf2pi1uZL1NF5jimEwgiUMbf5hAv9_sCPAs9gDAqAz5pCWlhIwLHE3Jxz7aWNmMhVN08ko5G1EJ0YWTbdVFPQB4rOTIAfyPPJ2me7dlcdtkTO0FrxkOpI7DndruNqbx1icD1bfs94piArdf6znLAtbT_hPmAbLd-tCxAWKU9aNnlf9vQDb9H4"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#f9f9f9] via-[#f9f9f9]/15 to-transparent opacity-85" />
                </div>

                {/* Text Content Overlay */}
                <div className="relative z-10 max-w-xl text-left md:mb-6 animate-fade-in">
                  <span className="text-[11px] text-[#ff6b00] font-bold uppercase tracking-[0.25em] block mb-2">
                    High-Street Digital Luxury
                  </span>
                  <h2 className="font-playfair text-display-lg-mobile md:text-5xl font-bold text-[#1a1c1c] leading-tight mb-6">
                    Discover the Latest Fashion Trends
                  </h2>
                  <button
                    onClick={() => {
                      // Smooth scroll down to Trending/Catalog section
                      document.getElementById('trending-shop')?.scrollIntoView({ behavior: 'smooth' });
                      triggerToast('Redirected to curated collections catalog');
                    }}
                    className="w-full sm:w-60 h-14 rounded-2xl bg-gradient-to-r from-[#ff6b00] to-[#1a1c1c] text-white font-bold tracking-widest text-xs flex items-center justify-center shadow-lg hover:brightness-110 active:scale-95 transition-all"
                  >
                    SHOP NEW INDEX
                  </button>
                </div>
              </section>
            )}

            {/* CURATED TRENDING COLLECTIONS IN HORIZONTAL SLIDER */}
            {currentView === 'home' && !isSearchActive && (
              <section id="trending-shop" className="py-12 bg-white border-t border-b border-[#1a1c1c]/10">
                <div className="px-5 md:px-16 mb-8 flex justify-between items-end max-w-7xl mx-auto">
                  <div>
                    <span className="text-[#a04100] font-medium tracking-widest uppercase text-xs">
                      Curated Indexes
                    </span>
                    <h3 className="font-playfair text-2xl md:text-3xl font-bold text-[#1a1c1c] mt-1">
                      Trending Styles
                    </h3>
                  </div>
                  <button
                    onClick={() => {
                      setCurrentView('collections');
                      triggerToast('Displaying collection galleries');
                    }}
                    className="text-[#5f5e5e] hover:text-[#ff6b00] font-bold text-xs uppercase tracking-widest flex items-center gap-1.5 transition-colors"
                  >
                    <span>View All</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>

                {/* Curated scroll list */}
                <div className="flex overflow-x-auto gap-6 px-5 md:px-16 pb-4 max-w-7xl mx-auto overflow-y-hidden hide-scrollbar scroll-smooth snap-x">
                  {curatedCollections.map((col, idx) => (
                    <div
                      key={idx}
                      onClick={() => {
                        setCurrentView(col.category as any);
                        triggerToast(`Loaded ${col.title} category`);
                      }}
                      className="min-w-[290px] md:min-w-[340px] snap-start flex flex-col gap-4 group cursor-pointer"
                    >
                      <div className="aspect-[3/4] rounded-2xl overflow-hidden relative shadow-sm border border-[#1a1c1c]/5">
                        <img
                          src={col.image}
                          alt={col.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/10 to-transparent flex flex-col justify-end p-6" />
                        
                        <div className="absolute bottom-5 left-5 text-left text-white">
                          <span className="text-[9px] uppercase tracking-wider font-bold text-[#ffdbcc] opacity-90 block mb-1">
                            {col.tagline}
                          </span>
                          <h4 className="font-playfair text-xl font-bold tracking-tight">
                            {col.title}
                          </h4>
                        </div>
                      </div>
                      <p className="font-bold text-xs tracking-wider uppercase text-[#a04100] flex items-center gap-1.5 px-1 hover:text-[#ff6b00] transition-colors">
                        <span>EXPLORE LUXE</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </p>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {/* NEW ARRIVALS & PRODUCTS CATALOG DYNAMIC GRID */}
            <section className="max-w-7xl mx-auto px-5 md:px-16 py-6 space-y-10">
              
              {/* Category Breadcrumbs / Headers */}
              <div className="border-b border-[#1a1c1c]/10 pb-5.5 flex flex-wrap justify-between items-baseline gap-4">
                <div>
                  <span className="text-xs font-semibold text-[#5a4136]/60 uppercase tracking-widest block">
                    {currentView === 'home' ? 'LUXURY INDEX' : `${currentView.toUpperCase()}'S BOUTIQUE`}
                  </span>
                  <h3 className="font-playfair text-3xl font-bold text-[#1a1c1c] tracking-tight mt-1">
                    {isSearchActive && searchQuery ? `Search Results: ${searchQuery}` : currentView === 'home' ? 'New Arrivals' : `${currentView.charAt(0).toUpperCase() + currentView.slice(1)} Collections`}
                  </h3>
                </div>

                {/* Sorting & Filter status flags */}
                <div className="flex gap-2.5">
                  <span className="text-[10px] bg-[#f3f3f3] text-[#1a1c1c] py-1.5 px-3 rounded-full font-bold uppercase tracking-widest flex items-center gap-1.5 border border-[#1a1c1c]/5">
                    <Filter className="w-3 h-3 text-[#ff6b00]" />
                    <span>Showing {filteredProducts.length} premium pieces</span>
                  </span>
                </div>
              </div>

              {/* No Products Alert */}
              {filteredProducts.length === 0 && (
                <div className="text-center py-20 bg-white rounded-3xl border border-[#1a1c1c]/10">
                  <ShieldAlert className="w-12 h-12 text-[#ba1a1a] mx-auto mb-4" />
                  <p className="text-base font-bold text-[#1a1c1c]">No digital assets found matching search parameters</p>
                  <p className="text-xs text-[#5f5e5e] mt-2 mb-6">Reset keyword query vectors or search default boutique collections</p>
                  <button
                    onClick={() => {
                      setSearchQuery('');
                      setCurrentView('home');
                      setIsSearchActive(false);
                    }}
                    className="px-6 py-3 bg-[#a04100] text-white text-xs font-bold uppercase tracking-widest rounded-xl hover:bg-[#ff6b00] transition-colors"
                  >
                    RESET DIGITAL INDEX
                  </button>
                </div>
              )}

              {/* Grid block */}
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8">
                {filteredProducts.map((product) => {
                  const isFav = favorites.includes(product.id);
                  return (
                    <div
                      key={product.id}
                      className="flex flex-col gap-3 group bg-white p-4 rounded-2xl border border-[#1a1c1c]/5 transition-all hover:border-[#ff6b00]/15"
                    >
                      {/* Interactive hover product cover */}
                      <div className="aspect-[3/4] rounded-xl bg-[#eeeeee] overflow-hidden relative shadow-sm">
                        
                        {/* Favorite button toggle */}
                        <button
                          onClick={() => handleToggleFavorite(product.id)}
                          className="absolute top-3.5 right-3.5 z-10 w-9.5 h-9.5 rounded-full bg-white flex items-center justify-center text-[#ff6b00] shadow-md border border-[#1a1c1c]/5 hover:scale-105 active:scale-95 transition-transform"
                          title="Save to favorites"
                        >
                          <Heart
                            className="w-4.5 h-4.5"
                            fill={isFav ? '#ff6b00' : 'none'}
                            stroke={isFav ? '#ff6b00' : 'currentColor'}
                          />
                        </button>

                        <img
                          src={product.image}
                          alt={product.name}
                          onClick={() => setSelectedProduct(product)}
                          className="w-full h-full object-cover group-hover:scale-105 transition-all duration-500 cursor-pointer"
                        />

                        {product.tag && (
                          <span className="absolute top-3.5 left-3.5 z-10 text-[9px] bg-black text-white px-2.5 py-1.5 rounded-md font-bold uppercase tracking-widest shadow-sm">
                            {product.tag}
                          </span>
                        )}
                      </div>

                      {/* Info & Price summary click to open details */}
                      <div className="flex justify-between items-start mt-1 px-1">
                        <div>
                          <h4
                            onClick={() => setSelectedProduct(product)}
                            className="font-semibold text-xs text-[#1a1c1c] uppercase tracking-wider hover:text-[#ff6b00] cursor-pointer transition-colors"
                          >
                            {product.name}
                          </h4>
                          <div className="flex items-center gap-1 mt-1 text-[10px] uppercase font-bold text-gray-400">
                            <span>{product.category}</span>
                            <span>•</span>
                            <div className="flex items-center text-amber-500">
                              <Star className="w-3 h-3 fill-amber-500 mr-0.5" />
                              <span>{product.rating}</span>
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <span className="text-sm font-bold text-[#a04100]">
                            ${product.price.toFixed(2)}
                          </span>
                          {product.originalPrice && (
                            <span className="text-[10px] text-[#5f5e5e] line-through block">
                              ${product.originalPrice.toFixed(2)}
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Action buttons list */}
                      <div className="grid grid-cols-2 gap-2 px-1 mt-2">
                        <button
                          onClick={() => setSelectedProduct(product)}
                          className="py-3 border border-[#1a1c1c]/10 text-[#1a1c1c] bg-white rounded-xl text-[10px] font-bold uppercase tracking-wider hover:bg-stone-50 transition-colors"
                        >
                          Explore Specs
                        </button>
                        <button
                          onClick={() => handleAddToBag(product, product.sizes[0] || 'XS', product.colors[0], 1)}
                          className="py-3 bg-[#a04100] group-hover:bg-[#ff6b00] text-white rounded-xl text-[10px] font-bold uppercase tracking-widest flex items-center justify-center gap-1.5 transition-colors shadow-sm active:scale-95"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          <span>Add to Bag</span>
                        </button>
                      </div>

                    </div>
                  );
                })}
              </div>

            </section>

            {/* BEST SELLERS VERTICAL LIST */}
            {currentView === 'home' && !isSearchActive && (
              <section className="bg-stone-100/50 border-t border-b border-[#1a1c1c]/5 py-12">
                <div className="max-w-7xl mx-auto px-5 md:px-16 grid grid-cols-1 md:grid-cols-2 gap-10">
                  
                  {/* Left info column */}
                  <div className="flex flex-col justify-center text-left">
                    <span className="text-[#ff6b00] font-bold text-xs uppercase tracking-[0.25em] block mb-3">
                      SOUGHT AFTER CATALOGS
                    </span>
                    <h3 className="font-playfair text-3xl md:text-4xl font-bold text-[#1a1c1c] leading-tight mb-4">
                      The Best Selling High-Street Uniform
                    </h3>
                    <p className="text-sm text-[#5f5e5e] leading-relaxed mb-6 max-w-sm">
                      Engineered tailoring configured with dynamic tech performance stretching. Lightweight fibers certified for fluid luxury.
                    </p>
                    <div className="flex gap-4">
                      <div className="bg-white p-4 rounded-xl border border-[#1a1c1c]/5 shadow-xs">
                        <Award className="w-6 h-6 text-[#ff6b00] mb-2" />
                        <span className="block text-xs font-bold text-[#1a1c1c] uppercase">Top Rated</span>
                        <span className="text-[10px] text-gray-500">Essential Tech Blazer</span>
                      </div>
                      <div className="bg-white p-4 rounded-xl border border-[#1a1c1c]/5 shadow-xs">
                        <TrendingUp className="w-6 h-6 text-[#ff6b00] mb-2" />
                        <span className="block text-xs font-bold text-[#1a1c1c] uppercase">Selling Fast</span>
                        <span className="text-[10px] text-gray-500">Urban Motion Sneakers</span>
                      </div>
                    </div>
                  </div>

                  {/* Right product list column */}
                  <div className="space-y-4 text-left">
                    {/* Bestseller Card 1 */}
                    {products.filter(p => p.isBestSeller).map((product) => (
                      <div
                        key={product.id}
                        className="flex gap-4 items-center bg-white p-4 rounded-2xl border border-[#1a1c1c]/5 hover:border-[#ff6b00]/15 transition-all shadow-xs"
                      >
                        <div
                          onClick={() => setSelectedProduct(product)}
                          className="w-20 h-24 rounded-lg overflow-hidden flex-shrink-0 bg-[#eeeeee] cursor-pointer"
                        >
                          <img className="w-full h-full object-cover" src={product.image} alt={product.name} />
                        </div>
                        <div className="flex-grow">
                          <span className="text-[9px] text-[#ff6b00] font-bold tracking-widest uppercase">
                            {product.tag}
                          </span>
                          <h4
                            onClick={() => setSelectedProduct(product)}
                            className="font-semibold text-xs text-[#1a1c1c] mt-0.5 hover:text-[#ff6b00] cursor-pointer"
                          >
                            {product.name}
                          </h4>
                          <p className="text-xs text-[#a04100] font-bold mt-1">${product.price.toFixed(2)}</p>
                          <div className="flex gap-1.5 mt-2">
                            {product.colors.map((c, i) => (
                              <div
                                key={i}
                                className="w-3.5 h-3.5 rounded-full border border-gray-200"
                                style={{ backgroundColor: c.hex }}
                                title={c.name}
                              />
                            ))}
                          </div>
                        </div>

                        <button
                          onClick={() => handleAddToBag(product, product.sizes[0] || 'S', product.colors[0], 1)}
                          className="w-11 h-11 rounded-lg bg-[#a04100] hover:bg-[#ff6b00] text-white flex items-center justify-center transition-colors shadow-sm active:scale-95"
                          title="Instant Add"
                        >
                          <ShoppingBag className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>

                </div>
              </section>
            )}

            {/* EXCLUSIVE PROMOTION BANNER */}
            {currentView === 'home' && (
              <section className="max-w-7xl mx-auto px-5 md:px-16 my-10 animate-fade-in text-left">
                <div className="relative h-52 rounded-3xl overflow-hidden flex items-center p-8 md:p-12 bg-zinc-900 group shadow-md">
                  <div className="absolute inset-0 z-0 opacity-45">
                    <div className="w-full h-full bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-[#ff6b00] to-transparent animate-pulse" />
                  </div>
                  
                  <div className="relative z-10 max-w-md">
                    <span className="text-[10px] text-[#ff6b00] font-bold uppercase tracking-[0.25em]">
                      Exclusive Access Invitation
                    </span>
                    <h3 className="font-playfair text-2xl md:text-3xl font-bold text-white mt-1.5">
                      Join Sitch Prime
                    </h3>
                    <p className="text-white/60 text-xs mt-1">
                      Unlock complimentary worldwide express DHL shipping on all seasonal orders with zero limit minimums.
                    </p>
                    <button
                      onClick={handleJoinPrime}
                      disabled={isPrime}
                      className="mt-4.5 bg-white text-[#1a1c1c] hover:bg-[#ff6b00] hover:text-white px-5 py-2.5 rounded-lg text-[10px] font-bold uppercase tracking-widest transition-all shadow-md active:scale-95 flex items-center gap-2"
                    >
                      <Crown className="w-4 h-4" />
                      {isPrime ? 'SITCH PRIME ACTIVE' : 'ACTIVATE COMPLIMENTARY MEMBERSHIP'}
                    </button>
                  </div>

                  <div className="absolute right-[-40px] bottom-[-40px] w-48 h-48 bg-[#ff6b00]/20 blur-[80px] rounded-full" />
                </div>
              </section>
            )}

          </div>
        )}

      </main>

      {/* SITCH PORTAL ELEVATED FOOTER */}
      <footer className="w-full pt-16 pb-8 bg-zinc-900 text-[#f9f9f9] border-t border-[#1a1c1c]">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 px-5 md:px-16 max-w-7xl mx-auto text-left">
          
          {/* Col 1 Brand Statement */}
          <div className="space-y-4">
            <h4 className="font-playfair text-xl font-bold tracking-widest uppercase text-[#ff6b00]">
              SITCH PORTAL
            </h4>
            <p className="text-xs text-stone-400 max-w-xs leading-relaxed">
              Curating high-street digital luxury for the modern digital nomad. Effortless logistics, impeccably crafted sewing algorithms.
            </p>
            {/* Newsletter input inside Footer */}
            <div className="pt-2">
              {newsletterSubscribed ? (
                <div className="flex items-center gap-2 text-xs font-bold text-emerald-400">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>CATALOG DISCIPLINE SECURED</span>
                </div>
              ) : (
                <form onSubmit={handleNewsletterSubmit} className="space-y-2">
                  <label className="block text-[9px] uppercase tracking-widest text-[#ff6b00] font-bold">
                    Join Private Catalogue Releases
                  </label>
                  <div className="flex gap-2 max-w-xs">
                    <input
                      type="email"
                      required
                      placeholder="nomad@sitch.com"
                      value={newsletterEmail}
                      onChange={(e) => setNewsletterEmail(e.target.value)}
                      className="bg-[#1a1c1c] text-white border border-stone-800 rounded-xl px-3.5 h-10 text-xs w-full focus:outline-none focus:border-[#ff6b00] outline-none"
                    />
                    <button
                      type="submit"
                      className="bg-[#ff6b00] text-white text-[10px] uppercase font-bold tracking-widest px-4 rounded-xl hover:bg-white hover:text-black transition-colors"
                    >
                      Join
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>

          {/* Col 2 Shop Category indexes */}
          <div className="flex flex-col gap-3">
            <span className="font-bold text-[10px] text-stone-300 uppercase tracking-widest mb-1 block">
              Digital Catalogs
            </span>
            <button
              onClick={() => {
                setCurrentView('men');
                triggerToast("Loaded Men's Wardrobe");
              }}
              className="text-stone-400 hover:text-[#ff6b00] text-xs transition-colors block text-left"
            >
              Men’s Technical Apparel
            </button>
            <button
              onClick={() => {
                setCurrentView('women');
                triggerToast("Loaded Women's Wardrobe");
              }}
              className="text-stone-400 hover:text-[#ff6b00] text-xs transition-colors block text-left"
            >
              Women’s Evening Silk Gowns
            </button>
            <button
              onClick={() => {
                setCurrentView('accessories');
                triggerToast("Loaded Accessories Index");
              }}
              className="text-stone-400 hover:text-[#ff6b00] text-xs transition-colors block text-left"
            >
              Leather Handbags &amp; Footwear
            </button>
            <button
              onClick={() => {
                setCurrentView('collections');
                triggerToast('Loaded Curated Collections');
              }}
              className="text-stone-400 hover:text-[#ff6b00] text-xs transition-colors block text-left"
            >
              Seasonal Lookbook Look indexes
            </button>
          </div>

          {/* Col 3 Logistics Support */}
          <div className="flex flex-col gap-3 text-left">
            <span className="font-bold text-[10px] text-stone-300 uppercase tracking-widest mb-1 block">
              System Support
            </span>
            <button
              onClick={() => {
                setCurrentView('about');
                triggerToast('Our Philosophy loaded');
              }}
              className="text-stone-400 hover:text-[#ff6b00] text-xs transition-colors block text-left"
            >
              Philosophical Manifesto
            </button>
            <span className="text-stone-400 text-xs">
              DHL Logistics Partner routing
            </span>
            <span className="text-stone-400 text-xs">
              30-Day Tagged Returns Policy
            </span>
            <span className="text-stone-400 text-xs">
              Secure Stripe SSL payment
            </span>
          </div>

          {/* Col 4 Identity status */}
          <div className="space-y-4 text-left">
            <span className="font-bold text-[10px] text-stone-300 uppercase tracking-widest mb-1 block">
              Portal Verification
            </span>
            <div className="text-stone-400 text-xs space-y-2">
              <p>Node Registry status: <strong className="text-emerald-500 uppercase">Operational</strong></p>
              <p>Identity: <strong>NOMAD MEMBER</strong></p>
              <p>System Local Time: <strong>2026-06-10</strong></p>
            </div>
          </div>

        </div>

        {/* Outer credit line */}
        <div className="mt-16 pt-8 border-t border-stone-800 text-center text-stone-500 text-[10px] uppercase tracking-widest">
          <p>© 2026 SITCH PORTAL CO. ALL METADATA REGISTERED.</p>
        </div>
      </footer>

      {/* AUTHENTICATION SECURE DIALOG MODAL */}
      {showAuthModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="absolute inset-0 bg-[#1a1c1c]/50 backdrop-blur-sm"
            onClick={() => setShowAuthModal(false)}
          />
          <div className="relative w-full max-w-sm bg-white rounded-3xl p-8 shadow-2xl z-10 text-left border border-[#1a1c1c]/10 animate-fade-in">
            <div className="flex justify-between items-start mb-6">
              <div>
                <span className="text-[9px] text-[#ff6b00] font-bold uppercase tracking-widest">
                  Secure Connection
                </span>
                <h3 className="font-playfair text-2xl font-bold text-[#1a1c1c] mt-1">
                  Authenticate Node
                </h3>
              </div>
              <button
                onClick={() => setShowAuthModal(false)}
                className="text-gray-400 hover:text-black p-1 bg-stone-100 rounded-full"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleAuthSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-[#1a1c1c] uppercase tracking-wider mb-1.5">
                  Secure Email Address
                </label>
                <input
                  type="email"
                  required
                  placeholder="nomad@sitch.com"
                  value={inputEmail}
                  onChange={(e) => setInputEmail(e.target.value)}
                  className="w-full px-4 h-11 border border-[#1a1c1c]/10 rounded-xl text-sm focus:border-[#ff6b00] focus:ring-1 focus:ring-[#ff6b00] outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#1a1c1c] uppercase tracking-wider mb-1.5">
                  Customer Full name
                </label>
                <input
                  type="text"
                  required
                  placeholder="Arpan Agopan"
                  value={inputName}
                  onChange={(e) => setInputName(e.target.value)}
                  className="w-full px-4 h-11 border border-[#1a1c1c]/10 rounded-xl text-sm focus:border-[#ff6b00] focus:ring-1 focus:ring-[#ff6b00] outline-none"
                />
              </div>

              <div className="bg-[#f9f9f9] p-3 rounded-xl border border-stone-100 text-[11px] text-[#5f5e5e] leading-relaxed">
                Authentication triggers dynamic lookbook configurations. Session keying resides purely in client state container.
              </div>

              <button
                type="submit"
                className="w-full h-12 rounded-xl bg-[#ff6b00] hover:bg-[#a04100] text-white text-xs font-bold uppercase tracking-widest transition-colors shadow-md"
              >
                CONNECT ACCOUNT KEYS
              </button>
            </form>
          </div>
        </div>
      )}

      {/* DETAILED SPECIFICATIONS MODAL */}
      <ProductDetailModal
        product={selectedProduct}
        isOpen={selectedProduct !== null}
        onClose={() => setSelectedProduct(null)}
        onAddToBag={handleAddToBag}
        isFavorite={selectedProduct ? favorites.includes(selectedProduct.id) : false}
        onToggleFavorite={handleToggleFavorite}
      />

      {/* COURIER BAG CHECKOUT SLIDER */}
      <BagDrawer
        isOpen={isBagOpen}
        onClose={() => setIsBagOpen(false)}
        cart={cart}
        onUpdateQty={handleUpdateCartQty}
        onRemoveItem={handleRemoveCartItem}
        isPrimeMember={isPrime}
        onCheckoutComplete={handleCheckoutComplete}
      />

      {/* SIDE NAVIGATION CATEGORIZATION DRAWER */}
      <NavigationDrawer
        isOpen={isNavDrawerOpen}
        onClose={() => setIsNavDrawerOpen(false)}
        onNavigate={(view) => {
          if (view === 'collections') {
            setCurrentView('home');
            setTimeout(() => {
              document.getElementById('trending-shop')?.scrollIntoView({ behavior: 'smooth' });
            }, 100);
          } else {
            setCurrentView(view as any);
          }
        }}
        currentView={currentView}
        isLoggedIn={isLoggedIn}
        userEmail={userEmail}
        onOpenAuth={() => setShowAuthModal(true)}
      />

    </div>
  );
}
