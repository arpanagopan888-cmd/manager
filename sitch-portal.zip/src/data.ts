import { Product } from './types';

export const products: Product[] = [
  {
    id: 'wool-sculpt-coat',
    name: 'Wool Sculpt Coat',
    price: 349.00,
    originalPrice: 420.00,
    category: 'women',
    isNewArrival: true,
    tag: 'Hot',
    rating: 4.8,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAo7D7ILP-FkLR-aWENC0nOf1PjKkUheJJV0S9E0trjAXPHNru5tIMXDOG0iq7zLWvuxlynbHfOvKz3AbKjKyxpr_E5ht8aDOC965qmyAfuRU7kF0AK1qmH_QJkpJEOxdwHAIP33GtgfoU7SR8wv-HBnOZ9tEZ9OdPOJvKu8_SC_z5bY1-V_RcnnRcF4Wn0HzVRRWWO650-yK0yusbzAc6dJw76DU1YUIza7VtT4Ex0becx7yHe89pAnl9_9uy5FxokgbJYWvbOE6U',
    description: 'A modern fashion statement. Crafted from premium double-faced organic wool, this structural coat features precise geometric lines, drop shoulders, and custom-engineered magnetic seam closures designed for heavy protection with ultra-light fluid wearing.',
    sizes: ['XS', 'S', 'M', 'L', 'XL'],
    colors: [
      { name: 'Charcoal Slate', hex: '#2c2e30' },
      { name: 'Pure Amber', hex: '#ff6b00' },
      { name: 'Chalk White', hex: '#f3f4f6' }
    ],
    details: [
      '100% GOTS certified organic wool warp',
      'Fully lined with water-repellent silk-blend membrane',
      'Magnetic pocket closures and concealed double zipper',
      'Dry clean only',
      'Designed in Copenhagen, manufactured in premium fair-trade European workshops'
    ]
  },
  {
    id: 'amber-silk-gown',
    name: 'Amber Silk Gown',
    price: 599.00,
    category: 'women',
    isNewArrival: true,
    isTrending: true,
    tag: 'Rare',
    rating: 5.0,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBPCMg4L4aFfRbnnx2WemAkHqXwXCOjXsqnW5RgmupNLv6Q1m-pnPiED3Z5ZXNq6sAMsYYxcj2GoPvzueJSeExcI8j5Y9xCjxGLLS5K-ADHJ8Ohzd5K25fSTM5uV1B17Hmstje-PZnW1hRCCNOkVQbHkOxjmptDlN4PxJFQWyapqOpCRO5gWOBGarv37zb-drCb4QF5gSIiDXQwqm2nmwbKL3Pir3VBxU5X3rgDMb93NzqWgNh0mK-u1zCBVbtUAkmZJWPbgp3qwUg',
    description: 'Elevate your evening presence. A high-fashion showstopper constructed from heavy 30mm mulberry silk charmeuse. Bias-cut to gently drape the forms of the body while establishing a radiant surface glow in light.',
    sizes: ['XXS', 'XS', 'S', 'M', 'L'],
    colors: [
      { name: 'Vibrant Amber', hex: '#ff6b00' },
      { name: 'Obsidian Black', hex: '#111827' }
    ],
    details: [
      '100% heavy 30mm Mulberry Silk Charmeuse',
      'French seam construction throughout',
      'Adjustable delicate cross-back silk bindings',
      'Includes premium presentation suite and custom silk hanger',
      'Made in Italy'
    ]
  },
  {
    id: 'essential-tech-blazer',
    name: 'Essential Tech Blazer',
    price: 249.00,
    originalPrice: 299.00,
    category: 'men',
    isBestSeller: true,
    tag: 'Top Rated',
    rating: 4.9,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBsf-3rfxGgibUxj2FLUA5YbPev4yUzyBt7BKJwV4W5ym5YAWOam4JgtnwOEzRpF_ffVSkEHSA6jylNwbpiEgdBNhkC-7-HFmVr6Rcr9PiWjl8ufyiLAaWt2I1MysESiSgnb10lfVhkIe0R5jR2BQ_lY5tXdhKs3gzQ4vQ7jWI1AiiOb_Z0UeJy3_RABW2RhDOSFahdzc3-RuxRsBm3Xugh7PMj5yGkwm8hSCcZuGvHd0WkMgvNc9VUFl3V9IHeiPBHdiGCiO1kAhY',
    description: 'Precision engineering meets classic Savile Row tailoring. The Essential Tech Blazer utilizes a stretch windproof merino wool blend that rejects wrinkles, water, and debris, while maintaining soft form over long-haul travels.',
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    colors: [
      { name: 'Charcoal Gray', hex: '#374151' },
      { name: 'High-Street Orange', hex: '#ff6b00' },
      { name: 'Void Black', hex: '#09090b' }
    ],
    details: [
      '74% Australian Merino, 22% Bio-Tech Windproof Poly, 4% Spandex',
      'Four-way stretch crease recovery tech',
      'Two concealed internal security zipper pockets with RFID blocking',
      'Minimalist water-shedding exterior coating',
      'Made in Portugal'
    ]
  },
  {
    id: 'urban-motion-sneakers',
    name: 'Urban Motion Sneakers',
    price: 189.00,
    category: 'accessories',
    isBestSeller: true,
    tag: 'Selling Fast',
    rating: 4.7,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuD5e0TYqyL1EG6cejNBruA6eVCXPKcGF3gMQZ0_BBLhed14XrhTn0WLEW_7kx1ehSQIiG54h64gycKdrr9sfyHeV6LcT0MxrxQbB4RDvRF4iBQrT4t1yZm0VSKigtEhsws-_I4jSJQUgNw9PGc5ecNaT7HBE9Lk6UdDc5z7JV4WC6cYtEZlc3O6DwhfLTi5tdqVKDUMnLlC0CllL5OBXWMaa8RlVfe5dcRKpD6Outlfjm7d2d_5FrLPDTZq527c21dnItRDY-LFJ4Q',
    description: 'Redefine modern motion. Built with lightweight custom-knit recycled ocean plastics and featuring reactive, biomimetic foam soles for high energy retrieval. Accented with signature luxury orange leather pulls.',
    sizes: ['7', '8', '9', '10', '11', '12'],
    colors: [
      { name: 'Stealth White / Orange', hex: '#e5e7eb' },
      { name: 'Void Black / Dark Knight', hex: '#000000' }
    ],
    details: [
      'Engineered knit upper using 100% recycled nylon and ocean polymers',
      'Vegetable-tanned full grain calfskin accents at pull tabs',
      'Responsive carbon fiber center shank for high-street agility',
      'Micro-mesh ventilation channels',
      'Assembled in Tokyo'
    ]
  },
  {
    id: 'lux-leather-handbag',
    name: 'Lux Leather Porter-Bag',
    price: 450.00,
    category: 'accessories',
    isTrending: true,
    tag: 'Exclusive',
    rating: 4.9,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAMtaUFK0Z8bxHafTr9ybo2xO9JPsd5YW6jl-RENraGpN3N2uhM0gXfo0VTFpSNo6U8vLXyLzidwxlJaN-V1x_I4g4iMqmDjDcI5Fx6_zaq2Mnz9bbsDoFPwi9Syo8lfbBtv_A2gY_HziKP26fDW6wpNwO4nocFRPtd67ruCtmiWzuzSFL_zE01PX0El5ZixjLLgTp6VPKvmffnxtjZYDNd1aaFlCLjnAlCnONxPSbRXHA2c0oxIrk0juMjcblmZGj0Poz6TuneMx8',
    description: 'A structural masterpiece. Features premium full-grain Italian calf leather in a signature high-street orange tone with gold brushed solid brass hardware. Styled for either crossbody drape or handle carrying.',
    sizes: ['One Size'],
    colors: [
      { name: 'Signature Sitch Orange', hex: '#ff6b00' },
      { name: 'Alabaster White', hex: '#f9fafb' },
      { name: 'Nocturnal Black', hex: '#111827' }
    ],
    details: [
      '100% Italian full-grain pebble leather',
      'Suede lining and solid brass accessories',
      'Removable and adjustable leather shoulder strap',
      '24cm width x 18cm height x 8cm depth',
      'Hand-stitched in Florence'
    ]
  },
  {
    id: 'evening-wear-slip',
    name: 'Evening Wear Silk Slip',
    price: 320.00,
    category: 'women',
    isTrending: true,
    tag: 'Trendsetter',
    rating: 4.6,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCJA-5pU3FNbKV94cLh7Gk7Vt3xpAwDQqRdrCK-NxgLC9HDodYIYx_HjbihwsSr3x7-hPrwPCgz2xHRLX4KWQ_rOh5DAWkcXRvi8yjq-u0Vw4I34RK5lE2lBQf8pT9aFQyuh3q8f_0iX2PBfjTQQ3XF0YSBHj3fLzwcy5czmA4QCvPk4rCCTvQs4_u19uFNHt8NmDFhDBu_33w0udZUeFIX2058P7qLoBVYVq-sKzzwpqlOka-ARzI1NDB4kgZATlT6P35tLVDuCSw',
    description: 'Impeccable evening silk dress emphasizing raw luxury textures. Constructed carefully using premium silk satin to maximize liquid orange light highlights over a sophisticated environment.',
    sizes: ['XXS', 'XS', 'S', 'M', 'L'],
    colors: [
      { name: 'Liquid Sunset Orange', hex: '#ff5500' },
      { name: 'Midnight Charcoal', hex: '#1f2937' }
    ],
    details: [
      '100% fine double-weave satin silk',
      'Concealed back zip with mother-of-pearl closures',
      'Bias cut for natural shape pairing',
      'Dry clean only',
      'Handcrafted in Milan'
    ]
  },
  {
    id: 'urban-tailored-trench',
    name: 'Urban Tailored Trench',
    price: 380.00,
    originalPrice: 480.00,
    category: 'men',
    isTrending: true,
    tag: 'Must Have',
    rating: 4.7,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDeqwATZiY_a6B4mF2rojTMJq3iob382FE12gIGY5oLmiJW6h0dhILl0NjEVRtzZlhj9ONnPeSXlmJOJr4MelfZfx9hUuu8xTqcYrt0qtBogmxC2I5czkiDRtghwyBx5coD2NXbpDpIiwX0UGItf7S9oD13jGu1LZuqtFow-i78LNyrPixjnoUfz6kDKeokKh37AlhZzK-WerjGx93zQ-s030lYfirkPQ33HTmZKHqjcYfFwQmAA91LO1NNi6kBwJ3BLBD1MBeZAc4',
    description: 'An editorial urban jacket defined by classic tailoring lines. Outfitted with heavy-duty weatherproof gabardine tech structure coupled with high-fashion matte-steel buckles.',
    sizes: ['S', 'M', 'L', 'XL'],
    colors: [
      { name: 'Urban Charcoal Grey', hex: '#4b5563' },
      { name: 'Nocturnal Black', hex: '#0f172a' }
    ],
    details: [
      'Gabardine waterproof cotton alloy',
      'Subtle high-fashion metallic matte accents',
      'Includes dual inner chest passport protectors',
      'Aesthetic belt adjustment system',
      'Designed in London'
    ]
  }
];

export const curatedCollections = [
  {
    title: 'Evening Wear',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCJA-5pU3FNbKV94cLh7Gk7Vt3xpAwDQqRdrCK-NxgLC9HDodYIYx_HjbihwsSr3x7-hPrwPCgz2xHRLX4KWQ_rOh5DAWkcXRvi8yjq-u0Vw4I34RK5lE2lBQf8pT9aFQyuh3q8f_0iX2PBfjTQQ3XF0YSBHj3fLzwcy5czmA4QCvPk4rCCTvQs4_u19uFNHt8NmDFhDBu_33w0udZUeFIX2058P7qLoBVYVq-sKzzwpqlOka-ARzI1NDB4kgZATlT6P35tLVDuCSw',
    tagline: 'Refinement after hours',
    category: 'women'
  },
  {
    title: 'Lux Accessories',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAMtaUFK0Z8bxHafTr9ybo2xO9JPsd5YW6jl-RENraGpN3N2uhM0gXfo0VTFpSNo6U8vLXyLzidwxlJaN-V1x_I4g4iMqmDjDcI5Fx6_zaq2Mnz9bbsDoFPwi9Syo8lfbBtv_A2gY_HziKP26fDW6wpNwO4nocFRPtd67ruCtmiWzuzSFL_zE01PX0El5ZixjLLgTp6VPKvmffnxtjZYDNd1aaFlCLjnAlCnONxPSbRXHA2c0oxIrk0juMjcblmZGj0Poz6TuneMx8',
    tagline: 'Sartorial signatures',
    category: 'accessories'
  },
  {
    title: 'Urban Tailoring',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDeqwATZiY_a6B4mF2rojTMJq3iob382FE12gIGY5oLmiJW6h0dhILl0NjEVRtzZlhj9ONnPeSXlmJOJr4MelfZfx9hUuu8xTqcYrt0qtBogmxC2I5czkiDRtghwyBx5coD2NXbpDpIiwX0UGItf7S9oD13jGu1LZuqtFow-i78LNyrPixjnoUfz6kDKeokKh37AlhZzK-WerjGx93zQ-s030lYfirkPQ33HTmZKHqjcYfFwQmAA91LO1NNi6kBwJ3BLBD1MBeZAc4',
    tagline: 'Modern office nomad',
    category: 'men'
  }
];
