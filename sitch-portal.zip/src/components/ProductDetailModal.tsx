import { useState } from 'react';
import { X, Star, Heart, ShoppingBag, Check, Shield, Truck, Undo } from 'lucide-react';
import { Product } from '../types';

interface ProductDetailModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  onAddToBag: (product: Product, size: string, color: { name: string; hex: string }, qty: number) => void;
  isFavorite: boolean;
  onToggleFavorite: (productId: string) => void;
}

export default function ProductDetailModal({
  product,
  isOpen,
  onClose,
  onAddToBag,
  isFavorite,
  onToggleFavorite,
}: ProductDetailModalProps) {
  if (!isOpen || !product) return null;

  const [selectedSize, setSelectedSize] = useState<string>(product.sizes[0] || 'One Size');
  const [selectedColor, setSelectedColor] = useState<{ name: string; hex: string }>(
    product.colors[0] || { name: 'Default', hex: '#000000' }
  );
  const [quantity, setQuantity] = useState<number>(1);
  const [activeTab, setActiveTab] = useState<'overview' | 'details' | 'shipping'>('overview');
  const [addedNotice, setAddedNotice] = useState<boolean>(false);

  const handleAdd = () => {
    onAddToBag(product, selectedSize, selectedColor, quantity);
    setAddedNotice(true);
    setTimeout(() => {
      setAddedNotice(false);
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop with extreme glassmorphism blur */}
      <div
        className="absolute inset-0 bg-[#1a1c1c]/60 backdrop-blur-md transition-opacity duration-300"
        onClick={onClose}
      />

      {/* Sheet Content Container */}
      <div className="relative w-full max-w-5xl bg-white rounded-3xl overflow-hidden shadow-2xl flex flex-col md:flex-row max-h-[90vh] md:max-h-[85vh] z-10 transition-all duration-300 transform scale-100">
        
        {/* Left Side: Product Image Display with interactive badges */}
        <div className="relative w-full md:w-1/2 h-[35vh] md:h-auto bg-[#eeeeee] flex items-center justify-center overflow-hidden">
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover transition-transform duration-700 hover:scale-105"
          />
          
          {/* Tag Overlay */}
          {product.tag && (
            <span className="absolute top-6 left-6 bg-[#a04100] text-white text-[10px] font-bold uppercase tracking-widest px-3 py-1.5 rounded-full z-10 shadow-sm">
              {product.tag}
            </span>
          )}

          {/* Wishlist toggle */}
          <button
            onClick={() => onToggleFavorite(product.id)}
            className="absolute top-6 right-6 w-11 h-11 rounded-full bg-white flex items-center justify-center text-[#a04100] hover:scale-110 active:scale-95 transition-transform shadow-md border border-[#1a1c1c]/5 z-10"
          >
            <Heart
              className="w-5 h-5 transition-colors"
              fill={isFavorite ? '#ff6b00' : 'none'}
              stroke={isFavorite ? '#ff6b00' : 'currentColor'}
            />
          </button>
        </div>

        {/* Right Side: Configuration & Specs */}
        <div className="w-full md:w-1/2 p-6 md:p-10 flex flex-col overflow-y-auto h-[55vh] md:h-auto">
          {/* Header */}
          <div className="flex justify-between items-start mb-4">
            <div>
              <span className="text-[11px] text-[#ff6b00] font-bold tracking-widest uppercase">
                {product.category}'s collection
              </span>
              <h2 className="font-playfair text-2xl md:text-3xl font-bold text-[#1a1c1c] tracking-tight mt-1">
                {product.name}
              </h2>
            </div>
            <button
              onClick={onClose}
              className="text-[#5f5e5e] hover:text-[#1a1c1c] p-2 hover:bg-[#ff6b00]/10 rounded-full transition-all"
            >
              <X className="w-5.5 h-5.5" />
            </button>
          </div>

          {/* Pricing & Rating Row */}
          <div className="flex items-center gap-4 mb-6">
            <span className="text-2xl font-bold text-[#a04100]">
              ${product.price.toFixed(2)}
            </span>
            {product.originalPrice && (
              <span className="text-sm text-[#5f5e5e] line-through">
                ${product.originalPrice.toFixed(2)}
              </span>
            )}
            
            <div className="h-4 w-[1px] bg-[#1a1c1c]/15" />
            
            {/* Stars */}
            <div className="flex items-center gap-1">
              {[...Array(5)].map((_, idx) => {
                const filled = idx < Math.floor(product.rating || 5);
                return (
                  <Star
                    key={idx}
                    className="w-4 h-4"
                    fill={filled ? '#ff6b00' : 'none'}
                    stroke="#ff6b00"
                  />
                );
              })}
              <span className="text-xs font-bold text-[#1a1c1c]/70 ml-1">
                ({product.rating || '4.8'})
              </span>
            </div>
          </div>

          {/* Interactive Specification Tabs */}
          <div className="flex border-b border-[#1a1c1c]/10 mb-6">
            <button
              className={`pb-3 text-xs font-bold tracking-widest uppercase border-b-2 mr-6 transition-all ${
                activeTab === 'overview'
                  ? 'border-[#ff6b00] text-[#a04100]'
                  : 'border-transparent text-[#5f5e5e] hover:text-[#1a1c1c]'
              }`}
              onClick={() => setActiveTab('overview')}
            >
              Overview
            </button>
            <button
              className={`pb-3 text-xs font-bold tracking-widest uppercase border-b-2 mr-6 transition-all ${
                activeTab === 'details'
                  ? 'border-[#ff6b00] text-[#a04100]'
                  : 'border-transparent text-[#5f5e5e] hover:text-[#1a1c1c]'
              }`}
              onClick={() => setActiveTab('details')}
            >
              Details
            </button>
            <button
              className={`pb-3 text-xs font-bold tracking-widest uppercase border-b-2 mr-6 transition-all ${
                activeTab === 'shipping'
                  ? 'border-[#ff6b00] text-[#a04100]'
                  : 'border-transparent text-[#5f5e5e] hover:text-[#1a1c1c]'
              }`}
              onClick={() => setActiveTab('shipping')}
            >
              Returns &amp; Logistics
            </button>
          </div>

          {/* Tab Information */}
          <div className="mb-6 flex-grow">
            {activeTab === 'overview' && (
              <p className="text-sm leading-relaxed text-[#5a4136]/90">
                {product.description}
              </p>
            )}

            {activeTab === 'details' && (
              <ul className="space-y-2">
                {product.details.map((detail, idx) => (
                  <li key={idx} className="text-xs text-[#5a4136] flex items-start gap-2.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#ff6b00] mt-1.5 shrink-0" />
                    <span>{detail}</span>
                  </li>
                ))}
              </ul>
            )}

            {activeTab === 'shipping' && (
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <Truck className="w-4.5 h-4.5 text-[#ff6b00] shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-xs font-bold text-[#1a1c1c]">Sitch Express Delivery</h4>
                    <p className="text-[11px] text-[#5f5e5e] mt-0.5">
                      Complimentary express courier transit for members. Carbon-neutral parcel routes arriving in 2-4 business days worldwide.
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Undo className="w-4.5 h-4.5 text-[#ff6b00] shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-xs font-bold text-[#1a1c1c]">Effortless Return Service</h4>
                    <p className="text-[11px] text-[#5f5e5e] mt-0.5">
                      Accepting undamaged returns with secure original tags within 30 days of receiving your package. Re-usable mailers provided.
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Color Selector */}
          <div className="mb-5">
            <span className="text-xs font-bold uppercase tracking-wider text-[#1a1c1c]">
              Color: <span className="text-[#5f5e5e] font-medium">{selectedColor.name}</span>
            </span>
            <div className="flex gap-3.5 mt-2.5">
              {product.colors.map((color, idx) => {
                const isSelected = selectedColor.name === color.name;
                return (
                  <button
                    key={idx}
                    onClick={() => setSelectedColor(color)}
                    className={`w-8 h-8 rounded-full flex items-center justify-center transition-all ${
                      isSelected
                        ? 'ring-2 ring-offset-2 ring-[#ff6b00]'
                        : 'hover:scale-105 active:scale-95'
                    }`}
                    style={{ backgroundColor: color.hex }}
                    title={color.name}
                  >
                    {isSelected && (
                      <Check className="w-4 h-4 text-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.5)]" />
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Size Selector */}
          {product.sizes[0] !== 'One Size' && (
            <div className="mb-6">
              <span className="text-xs font-bold uppercase tracking-wider text-[#1a1c1c]">
                Size Selection
              </span>
              <div className="flex flex-wrap gap-2 mt-2.5">
                {product.sizes.map((size, idx) => {
                  const isSelected = selectedSize === size;
                  return (
                    <button
                      key={idx}
                      onClick={() => setSelectedSize(size)}
                      className={`min-w-12 h-11 px-3.5 rounded-lg border text-xs font-bold uppercase transition-all ${
                        isSelected
                          ? 'bg-[#1a1c1c] text-white border-[#1a1c1c]'
                          : 'border-[#1a1c1c]/10 text-[#5f5e5e] hover:border-[#1a1c1c]/40 hover:text-[#1a1c1c]'
                      }`}
                    >
                      {size}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Add actions bar */}
          <div className="flex items-center gap-4 mt-auto">
            {/* Quantity */}
            <div className="flex items-center border border-[#1a1c1c]/10 rounded-xl h-[56px] overflow-hidden bg-[#f9f9f9]">
              <button
                onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                className="w-11 h-full font-bold flex items-center justify-center text-[#5f5e5e] hover:bg-[#1a1c1c]/5 hover:text-[#1a1c1c]"
              >
                -
              </button>
              <span className="w-10 text-center font-semibold text-sm text-[#1a1c1c]">
                {quantity}
              </span>
              <button
                onClick={() => setQuantity((q) => q + 1)}
                className="w-11 h-full font-bold flex items-center justify-center text-[#5f5e5e] hover:bg-[#1a1c1c]/5 hover:text-[#1a1c1c]"
              >
                +
              </button>
            </div>

            {/* Clickable Action Button */}
            <button
              onClick={handleAdd}
              disabled={addedNotice}
              className={`flex-grow h-[56px] rounded-xl font-bold text-xs tracking-widest uppercase flex items-center justify-center gap-2.5 transition-all shadow-md active:scale-95 ${
                addedNotice
                  ? 'bg-emerald-600 text-white cursor-default'
                  : 'bg-[#ff6b00] text-white hover:bg-[#a04100]'
              }`}
            >
              {addedNotice ? (
                <>
                  <Check className="w-4 h-4 animate-bounce" />
                  ADDED TO BAG
                </>
              ) : (
                <>
                  <ShoppingBag className="w-4.5 h-4.5" />
                  ADD TO BAG
                </>
              )}
            </button>
          </div>

          {/* Authentized assurance chips */}
          <div className="mt-5 grid grid-cols-2 gap-3.5 border-t border-[#1a1c1c]/5 pt-4">
            <div className="flex items-center gap-2 text-[10px] uppercase tracking-wider text-[#5f5e5e]">
              <Shield className="w-4 h-4 text-[#ff6b00]" />
              <span>100% Genuine Luxury</span>
            </div>
            <div className="flex items-center gap-2 text-[10px] uppercase tracking-wider text-[#5f5e5e]">
              <Undo className="w-4 h-4 text-[#ff6b00]" />
              <span>Complimentary Returns</span>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
