import { Home, Shirt, Sparkles, Mail, LogIn, X, Info, CreditCard, ShieldCheck } from 'lucide-react';

interface NavigationDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (view: 'home' | 'men' | 'women' | 'accessories' | 'collections' | 'profile' | 'about') => void;
  currentView: string;
  isLoggedIn: boolean;
  userEmail?: string;
  onOpenAuth: () => void;
}

export default function NavigationDrawer({
  isOpen,
  onClose,
  onNavigate,
  currentView,
  isLoggedIn,
  userEmail,
  onOpenAuth,
}: NavigationDrawerProps) {
  return (
    <div
      className={`fixed inset-0 z-50 transition-opacity duration-300 ${
        isOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
      }`}
    >
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-[#1a1c1c]/40 backdrop-blur-xs transition-opacity duration-300"
        onClick={onClose}
      />

      {/* Drawer content */}
      <nav
        className={`absolute top-0 left-0 h-full w-80 bg-white/95 backdrop-blur-xl border-r border-[#1a1c1c]/10 shadow-2xl flex flex-col p-8 transition-transform duration-300 ease-out ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex justify-between items-center mb-8">
          <button
            onClick={() => {
              onNavigate('home');
              onClose();
            }}
            className="font-playfair text-xl font-bold tracking-widest uppercase text-[#a04100] active:scale-95 transition-transform"
          >
            SITCH PORTAL
          </button>
          <button
            onClick={onClose}
            className="text-[#5f5e5e] hover:text-[#a04100] p-1.5 rounded-full hover:bg-[#ff6b00]/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Categories */}
        <div className="flex flex-col gap-3 flex-grow">
          <button
            onClick={() => {
              onNavigate('home');
              onClose();
            }}
            className={`w-full text-left p-3 rounded-lg flex items-center gap-3.5 font-medium transition-all ${
              currentView === 'home'
                ? 'bg-[#ff6b00]/10 text-[#a04100]'
                : 'text-[#5f5e5e] hover:bg-[#ff6b00]/5 hover:text-[#1a1c1c]'
            }`}
          >
            <Home className="w-5 h-5" />
            <span>Home</span>
          </button>

          <button
            onClick={() => {
              onNavigate('men');
              onClose();
            }}
            className={`w-full text-left p-3 rounded-lg flex items-center gap-3.5 font-medium transition-all ${
              currentView === 'men'
                ? 'bg-[#ff6b00]/10 text-[#a04100]'
                : 'text-[#5f5e5e] hover:bg-[#ff6b00]/5 hover:text-[#1a1c1c]'
            }`}
          >
            <Shirt className="w-5 h-5" />
            <span>Men's Shop</span>
          </button>

          <button
            onClick={() => {
              onNavigate('women');
              onClose();
            }}
            className={`w-full text-left p-3 rounded-lg flex items-center gap-3.5 font-medium transition-all ${
              currentView === 'women'
                ? 'bg-[#ff6b00]/10 text-[#a04100]'
                : 'text-[#5f5e5e] hover:bg-[#ff6b00]/5 hover:text-[#1a1c1c]'
            }`}
          >
            <Shirt className="w-5 h-5" />
            <span>Women's Shop</span>
          </button>

          <button
            onClick={() => {
              onNavigate('accessories');
              onClose();
            }}
            className={`w-full text-left p-3 rounded-lg flex items-center gap-3.5 font-medium transition-all ${
              currentView === 'accessories'
                ? 'bg-[#ff6b00]/10 text-[#a04100]'
                : 'text-[#5f5e5e] hover:bg-[#ff6b00]/5 hover:text-[#1a1c1c]'
            }`}
          >
            <Sparkles className="w-5 h-5" />
            <span>Lux Accessories</span>
          </button>

          <hr className="my-3 border-[#1a1c1c]/10" />

          {/* Sitch Prime / Profile Links */}
          <button
            onClick={() => {
              onNavigate('profile');
              onClose();
            }}
            className={`w-full text-left p-3 rounded-lg flex items-center gap-3.5 font-medium transition-all ${
              currentView === 'profile'
                ? 'bg-[#ff6b00]/10 text-[#a04100]'
                : 'text-[#5f5e5e] hover:bg-[#ff6b00]/5 hover:text-[#1a1c1c]'
            }`}
          >
            <CreditCard className="w-5 h-5" />
            <span>Sitch Prime Access</span>
          </button>

          <button
            onClick={() => {
              onNavigate('about');
              onClose();
            }}
            className={`w-full text-left p-3 rounded-lg flex items-center gap-3.5 font-medium transition-all ${
              currentView === 'about'
                ? 'bg-[#ff6b00]/10 text-[#a04100]'
                : 'text-[#5f5e5e] hover:bg-[#ff6b00]/5 hover:text-[#1a1c1c]'
            }`}
          >
            <Info className="w-5 h-5" />
            <span>Our Philosophy</span>
          </button>
        </div>

        {/* User Info / Call To Action Footer */}
        <div className="mt-auto border-t border-[#1a1c1c]/10 pt-6">
          {isLoggedIn ? (
            <div className="flex flex-col gap-2 bg-[#f3f3f3] p-4 rounded-xl">
              <div className="flex items-center gap-2 text-xs font-semibold text-[#a04100] uppercase tracking-wider">
                <ShieldCheck className="w-4 h-4" />
                <span>Verified Member</span>
              </div>
              <p className="text-sm font-semibold truncate text-[#1a1c1c]">{userEmail}</p>
              <button
                onClick={() => {
                  onNavigate('profile');
                  onClose();
                }}
                className="text-xs text-left text-[#ff6b00] font-bold underline hover:text-[#a04100]"
              >
                Manage Sitch Membership
              </button>
            </div>
          ) : (
            <button
              onClick={() => {
                onClose();
                onOpenAuth();
              }}
              className="w-full h-12 rounded-xl border border-[#ff6b00] text-[#a04100] hover:bg-[#ff6b00]/10 font-bold tracking-wider text-xs flex items-center justify-center gap-2.5 transition-all"
            >
              <LogIn className="w-4 h-4" />
              AUTHENTICATE ACCOUNT
            </button>
          )}

          <div className="mt-4 text-[10px] text-center text-[#5a4136]/60 font-medium tracking-widest uppercase">
            SITCH PORTAL V1.8 • COPIED 2026
          </div>
        </div>
      </nav>
    </div>
  );
}
