import { useState, FormEvent } from 'react';
import { X, Trash2, Plus, Minus, CreditCard, ShieldCheck, ShoppingBag, CheckCircle2, Ticket } from 'lucide-react';
import { CartItem } from '../types';

interface BagDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  onUpdateQty: (idx: number, newQty: number) => void;
  onRemoveItem: (idx: number) => void;
  isPrimeMember: boolean;
  onCheckoutComplete: () => void;
}

export default function BagDrawer({
  isOpen,
  onClose,
  cart,
  onUpdateQty,
  onRemoveItem,
  isPrimeMember,
  onCheckoutComplete,
}: BagDrawerProps) {
  const [promoCode, setPromoCode] = useState<string>('');
  const [discountPercent, setDiscountPercent] = useState<number>(0);
  const [promoError, setPromoError] = useState<string | null>(null);
  const [promoSuccess, setPromoSuccess] = useState<string | null>(null);

  // Checkout sequence state variables
  const [isCheckingOut, setIsCheckingOut] = useState<boolean>(false);
  const [checkoutComplete, setCheckoutComplete] = useState<boolean>(false);
  const [address, setAddress] = useState<string>('Sitch Luxury Towers, Penthouse 4B, Singapore');
  const [receiptNumber, setReceiptNumber] = useState<string>('');

  const handleApplyPromo = (e: FormEvent) => {
    e.preventDefault();
    const cleanCode = promoCode.trim().toUpperCase();
    if (cleanCode === 'SITCHPRIME') {
      setDiscountPercent(20);
      setPromoSuccess('Promo "SITCHPRIME" active: 20% discount applied!');
      setPromoError(null);
    } else if (cleanCode === 'FREE') {
      setDiscountPercent(10);
      setPromoSuccess('Promo Code Accepted: 10% discount applied!');
      setPromoError(null);
    } else {
      setPromoError('Invalid coupon code. Try "SITCHPRIME".');
      setPromoSuccess(null);
    }
  };

  const getSubtotal = () => {
    return cart.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  };

  const discountAmount = getSubtotal() * (discountPercent / 100);
  const shippingFee = getSubtotal() > 500 || isPrimeMember ? 0 : 25.0;
  const grandTotal = getSubtotal() - discountAmount + shippingFee;

  const totalItemCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  const startCheckout = () => {
    setIsCheckingOut(true);
  };

  const completePayment = (e: FormEvent) => {
    e.preventDefault();
    setTimeout(() => {
      setReceiptNumber('SITCH-' + Math.floor(100000 + Math.random() * 900000));
      setCheckoutComplete(true);
      setIsCheckingOut(false);
    }, 1500);
  };

  const resetDrawer = () => {
    onCheckoutComplete();
    setCheckoutComplete(false);
    setIsCheckingOut(false);
    setPromoCode('');
    setDiscountPercent(0);
    setPromoError(null);
    setPromoSuccess(null);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-[#1a1c1c]/40 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      {/* Main Drawer Shell */}
      <div className="relative w-full max-w-md bg-white h-full flex flex-col shadow-2xl z-20 overflow-hidden">
        
        {/* State 1: Checkout success card */}
        {checkoutComplete ? (
          <div className="flex-grow flex flex-col items-center justify-center p-8 text-center bg-stone-50">
            <CheckCircle2 className="w-16 h-16 text-[#ff6b00] mb-6 animate-pulse" />
            <span className="text-[10px] text-[#ff6b00] font-bold tracking-widest uppercase">
              TRANSACTION APPROVED
            </span>
            <h3 className="font-playfair text-3xl font-bold text-[#1a1c1c] mt-2 mb-4">
              Receipt Secured
            </h3>
            <p className="text-sm text-[#5f5e5e] max-w-xs mb-6">
              Sitch luxury garments have been reserved under catalog order: <strong>{receiptNumber}</strong>. Express courier logistics have started.
            </p>
            <div className="w-full bg-white p-5 rounded-2xl border border-[#1a1c1c]/10 text-left mb-8 text-xs space-y-2.5">
              <div className="flex justify-between">
                <span className="text-[#5f5e5e]">Transit address:</span>
                <span className="font-semibold text-[#1a1c1c] truncate max-w-[200px]">{address}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#5f5e5e]">Shipping rate:</span>
                <span className="font-semibold text-emerald-600">Complimentary Express</span>
              </div>
              <div className="flex justify-between border-t border-dashed border-[#1a1c1c]/10 pt-2.5 font-bold text-sm">
                <span>Paid via card:</span>
                <span className="text-[#a04100]">${grandTotal.toFixed(2)}</span>
              </div>
            </div>
            <button
              onClick={resetDrawer}
              className="w-full h-12 bg-[#1a1c1c] hover:bg-[#ff6b00] text-white font-bold text-xs tracking-widest uppercase rounded-xl transition-all"
            >
              CONTINUE SHOPPING
            </button>
          </div>
        ) : isCheckingOut ? (
          /* State 2: Simulated Checkout Form */
          <div className="flex-grow flex flex-col h-full bg-white">
            <div className="p-6 border-b border-[#1a1c1c]/10 flex items-center justify-between">
              <h3 className="font-bold text-md tracking-wider uppercase text-[#1a1c1c]">
                SECURE SITCH CHECKOUT
              </h3>
              <button
                onClick={() => setIsCheckingOut(false)}
                className="text-xs text-[#ff6b00] hover:underline font-bold"
              >
                Go Back
              </button>
            </div>

            <form onSubmit={completePayment} className="p-6 flex-grow flex flex-col gap-5 overflow-y-auto">
              <div>
                <label className="block text-xs font-bold text-[#1a1c1c] uppercase tracking-wider mb-2">
                  Delivery Destination
                </label>
                <input
                  type="text"
                  required
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full px-4 h-11 border border-[#1a1c1c]/10 rounded-xl text-sm focus:border-[#ff6b00] focus:ring-1 focus:ring-[#ff6b00] outline-none"
                  placeholder="Street details, building, suite"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#1a1c1c] uppercase tracking-wider mb-2">
                  Cardholder’s Name
                </label>
                <input
                  type="text"
                  required
                  defaultValue="Arpan Agopan"
                  className="w-full px-4 h-11 border border-[#1a1c1c]/10 rounded-xl text-sm focus:border-[#ff6b00] focus:ring-1 focus:ring-[#ff6b00] outline-none"
                  placeholder="Full legal name"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#1a1c1c] uppercase tracking-wider mb-2">
                  Credit Card Number
                </label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    maxLength={19}
                    defaultValue="4111 8888 9999 1234"
                    className="w-full pl-11 pr-4 h-11 border border-[#1a1c1c]/10 rounded-xl text-sm focus:border-[#ff6b00] focus:ring-1 focus:ring-[#ff6b00] outline-none font-mono"
                    placeholder="xxxx xxxx xxxx xxxx"
                  />
                  <CreditCard className="w-5 h-5 absolute left-3.5 top-3 text-[#5f5e5e]" />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-[#1a1c1c] uppercase tracking-wider mb-2">
                    Expiry
                  </label>
                  <input
                    type="text"
                    required
                    defaultValue="12/28"
                    className="w-full px-4 h-11 border border-[#1a1c1c]/10 rounded-xl text-xs text-center focus:border-[#ff6b00] focus:ring-1 focus:ring-[#ff6b00] outline-none"
                    placeholder="MM/YY"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-[#1a1c1c] uppercase tracking-wider mb-2">
                    CVC Code
                  </label>
                  <input
                    type="password"
                    required
                    maxLength={3}
                    defaultValue="888"
                    className="w-full px-4 h-11 border border-[#1a1c1c]/10 rounded-xl text-xs text-center focus:border-[#ff6b00] focus:ring-1 focus:ring-[#ff6b00] outline-none"
                    placeholder="•••"
                  />
                </div>
              </div>

              <div className="mt-4 p-4 bg-[#f9f9f9] border border-[#1a1c1c]/5 rounded-xl space-y-2">
                <div className="flex justify-between text-xs">
                  <span className="text-[#5f5e5e]">Cart Items:</span>
                  <span className="font-semibold text-[#1a1c1c]">{totalItemCount} pcs</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-[#5f5e5e]">Total Fee:</span>
                  <span className="font-bold text-[#a04100]">${grandTotal.toFixed(2)}</span>
                </div>
              </div>

              <div className="mt-auto pt-4 flex flex-col gap-3">
                <div className="flex items-center justify-center gap-2 text-[10px] text-zinc-500 uppercase tracking-widest font-semibold">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>Verified Stripe Encryption Active</span>
                </div>
                <button
                  type="submit"
                  className="w-full h-14 rounded-xl bg-[#ff6b00] hover:bg-[#a04100] text-white font-bold text-xs tracking-widest uppercase flex items-center justify-center gap-2 hover:scale-[1.01] transition-transform shadow-md"
                >
                  SECURE PAYMENT (${grandTotal.toFixed(2)})
                </button>
              </div>
            </form>
          </div>
        ) : (
          /* State 3: Normal Bag Listing & Summary */
          <div className="flex-grow flex flex-col h-full">
            {/* Header */}
            <div className="p-6 border-b border-[#1a1c1c]/10 flex justify-between items-center bg-stone-50/50">
              <div className="flex items-center gap-2.5">
                <ShoppingBag className="w-5.5 h-5.5 text-[#a04100]" />
                <h3 className="font-playfair text-xl font-bold text-[#1a1c1c]">Your Bag</h3>
                <span className="text-[11px] bg-[#ff6b00] text-white px-2.5 py-0.5 rounded-full font-bold ml-1">
                  {totalItemCount}
                </span>
              </div>
              <button
                onClick={onClose}
                className="text-[#5f5e5e] hover:text-[#1a1c1c] p-1.5 hover:bg-[#ff6b00]/10 rounded-full transition-colors"
                id="close-drawer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Bag list content */}
            <div className="flex-grow overflow-y-auto p-6 space-y-5">
              {cart.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center py-20">
                  <ShoppingBag className="w-12 h-12 text-[#1a1c1c]/15 mb-4" />
                  <p className="text-sm font-semibold text-[#1a1c1c]">No luxury item added yet</p>
                  <p className="text-xs text-[#5f5e5e] mt-1 max-w-[200px]">
                    Browse our premium apparel collections to enrich your wardrobe state
                  </p>
                  <button
                    onClick={onClose}
                    className="mt-6 px-6 py-3 bg-[#a04100] text-white text-xs font-bold tracking-widest uppercase rounded-xl hover:bg-[#ff6b00] active:scale-95 transition-all"
                  >
                    DISCOVER NOW
                  </button>
                </div>
              ) : (
                cart.map((item, idx) => (
                  <div
                    key={idx}
                    className="flex gap-4 p-3 rounded-2xl bg-[#f9f9f9] border border-[#1a1c1c]/5 hover:border-[#ff6b00]/20 transition-all group"
                  >
                    {/* Picture */}
                    <div className="w-20 h-24 rounded-xl overflow-hidden shrink-0 bg-[#eeeeee]">
                      <img src={item.product.image} className="w-full h-full object-cover" alt="" />
                    </div>

                    {/* Metadata & controls */}
                    <div className="flex-grow flex flex-col min-w-0 justify-between">
                      <div>
                        <div className="flex justify-between items-start gap-1.5">
                          <h4 className="font-semibold text-xs text-[#1a1c1c] truncate">
                            {item.product.name}
                          </h4>
                          <span className="text-xs font-bold text-[#a04100] shrink-0">
                            ${(item.product.price * item.quantity).toFixed(2)}
                          </span>
                        </div>
                        <p className="text-[10px] text-[#5f5e5e] mt-1 flex gap-2 items-center flex-wrap">
                          {item.selectedSize !== 'One Size' && (
                            <span className="bg-white border border-[#1a1c1c]/5 px-1.5 py-0.5 rounded">
                              Size: {item.selectedSize}
                            </span>
                          )}
                          <span className="flex items-center gap-1">
                            <span
                              className="w-2.5 h-2.5 rounded-full inline-block border border-white"
                              style={{ backgroundColor: item.selectedColor.hex }}
                            />
                            {item.selectedColor.name}
                          </span>
                        </p>
                      </div>

                      {/* Controls inside bag */}
                      <div className="flex items-center justify-between">
                        <div className="flex items-center border border-[#1a1c1c]/10 rounded-lg overflow-hidden h-7 bg-white">
                          <button
                            onClick={() => onUpdateQty(idx, Math.max(1, item.quantity - 1))}
                            className="w-7 h-full text-[#5f5e5e] hover:bg-zinc-100 flex items-center justify-center font-bold text-xs"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="w-7 text-center font-bold text-xs text-[#1a1c1c]">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => onUpdateQty(idx, item.quantity + 1)}
                            className="w-7 h-full text-[#5f5e5e] hover:bg-zinc-100 flex items-center justify-center font-bold text-xs"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>

                        <button
                          onClick={() => onRemoveItem(idx)}
                          className="text-[#5f5e5e] hover:text-[#ba1a1a] p-1 rounded transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>

                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Calculations and payment buttons */}
            {cart.length > 0 && (
              <div className="border-t border-[#1a1c1c]/10 p-6 bg-stone-50 space-y-4">
                
                {/* Coupon Code input form */}
                <form onSubmit={handleApplyPromo} className="flex gap-2.5">
                  <div className="relative flex-grow">
                    <input
                      type="text"
                      className="w-full text-xs px-4 pr-8 h-10 border border-[#1a1c1c]/10 bg-white rounded-xl focus:border-[#ff6b00] outline-none uppercase font-semibold"
                      placeholder="ENTER SITCH COUPON"
                      value={promoCode}
                      onChange={(e) => setPromoCode(e.target.value)}
                    />
                    <Ticket className="w-4 h-4 absolute right-3 top-3 text-[#5f5e5e]/60" />
                  </div>
                  <button
                    type="submit"
                    className="bg-[#1a1c1c] text-white text-xs font-bold px-4 rounded-xl hover:bg-[#ff6b00] transition-colors"
                  >
                    Apply
                  </button>
                </form>

                {promoError && <p className="text-[10px] text-red-600 font-bold">{promoError}</p>}
                {promoSuccess && <p className="text-[10px] text-emerald-600 font-bold">{promoSuccess}</p>}

                {/* Totals table */}
                <div className="space-y-2 text-xs border-b border-[#1a1c1c]/5 pb-4">
                  <div className="flex justify-between">
                    <span className="text-[#5f5e5e]">Bag subtotal:</span>
                    <span className="font-semibold text-[#1a1c1c]">${getSubtotal().toFixed(2)}</span>
                  </div>

                  {discountPercent > 0 && (
                    <div className="flex justify-between text-emerald-600">
                      <span>Exclusive Discount ({discountPercent}%):</span>
                      <span>-${discountAmount.toFixed(2)}</span>
                    </div>
                  )}

                  <div className="flex justify-between">
                    <span className="text-[#5f5e5e]">Premium Courier Shipping:</span>
                    {shippingFee === 0 ? (
                      <span className="text-emerald-600 font-semibold uppercase tracking-wider text-[10px]">
                        Complimentary
                      </span>
                    ) : (
                      <span className="font-semibold text-[#1a1c1c]">${shippingFee.toFixed(2)}</span>
                    )}
                  </div>
                </div>

                <div className="flex justify-between items-end pt-1">
                  <div>
                    <span className="text-[10px] text-[#5f5e5e] uppercase tracking-wider block font-bold">
                      Est. Total Price
                    </span>
                    <span className="text-2xl font-bold text-[#a04100]">
                      ${grandTotal.toFixed(2)}
                    </span>
                  </div>

                  <button
                    onClick={startCheckout}
                    className="h-14 px-6 bg-[#ff6b00] hover:bg-[#a04100] text-white font-bold text-xs tracking-widest uppercase rounded-xl flex items-center gap-2 shadow-md transition-all active:scale-95"
                  >
                    <span>CHECKOUT NOW</span>
                  </button>
                </div>

              </div>
            )}

          </div>
        )}

      </div>
    </div>
  );
}
